# Claude Code 설정 적용 스크립트 (Windows)
# PowerShell 관리자 권한으로 실행

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Claude Code 설정 적용 중..." -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 현재 위치 확인
$CurrentPath = Get-Location
Write-Host "현재 위치: $CurrentPath" -ForegroundColor Yellow
Write-Host ""

# Claude 설정 폴더 경로
$ClaudeFolder = "$env:USERPROFILE\.claude"

# Claude 설정 폴더 존재 확인
if (-Not (Test-Path $ClaudeFolder)) {
    Write-Host "⚠️  Claude 설정 폴더가 없습니다." -ForegroundColor Red
    Write-Host "   Claude Code가 설치되어 있나요?" -ForegroundColor Yellow
    Write-Host "   폴더를 생성합니다: $ClaudeFolder" -ForegroundColor Yellow
    New-Item -ItemType Directory -Path $ClaudeFolder -Force | Out-Null
}

Write-Host "Claude 설정 폴더: $ClaudeFolder" -ForegroundColor Green
Write-Host ""

# 백업 생성
$BackupFolder = "$env:USERPROFILE\.claude_backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
if (Test-Path $ClaudeFolder) {
    Write-Host "기존 설정 백업 중..." -ForegroundColor Yellow
    Copy-Item -Path $ClaudeFolder -Destination $BackupFolder -Recurse -Force
    Write-Host "✅ 백업 완료: $BackupFolder" -ForegroundColor Green
    Write-Host ""
}

# 설정 파일 복사
Write-Host "설정 파일 복사 중..." -ForegroundColor Yellow

try {
    # .claude 폴더의 모든 내용 복사
    $SourceFolder = Join-Path $CurrentPath ".claude"

    if (Test-Path $SourceFolder) {
        Copy-Item -Path "$SourceFolder\*" -Destination $ClaudeFolder -Recurse -Force
        Write-Host "✅ 설정 파일 복사 완료!" -ForegroundColor Green
    } else {
        Write-Host "❌ .claude 폴더를 찾을 수 없습니다." -ForegroundColor Red
        Write-Host "   현재 위치: $CurrentPath" -ForegroundColor Yellow
        exit 1
    }
} catch {
    Write-Host "❌ 복사 실패: $_" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "✅ 설정 적용 완료!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "다음 단계:" -ForegroundColor Yellow
Write-Host "1. Claude Code를 재시작하세요" -ForegroundColor White
Write-Host "2. '/' 입력 시 '/generate-tests' 명령어 확인" -ForegroundColor White
Write-Host "3. Git 명령어가 자동 승인되는지 확인" -ForegroundColor White
Write-Host ""

Write-Host "백업 위치: $BackupFolder" -ForegroundColor Cyan
Write-Host ""

Write-Host "문제가 있으면 '설정_이전_가이드.txt'를 참고하세요." -ForegroundColor Yellow
Write-Host ""

pause
